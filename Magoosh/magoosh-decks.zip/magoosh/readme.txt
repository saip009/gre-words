Hi, saip009 here.

NOTE: It will not work with Python 3.x. Install Python 2.7.x.

You will find the necessary instructions here > https://github.com/saip009/gre-words

All the best.
